#include "finishedboba.h"
#include "ui_finishedboba.h"
#include "ui_bobamachine.h"
#include "bobamachine.h"

FinishedBoba::FinishedBoba(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::FinishedBoba)
{
    ui->setupUi(this);



}

FinishedBoba::~FinishedBoba()
{
    delete ui;
}
