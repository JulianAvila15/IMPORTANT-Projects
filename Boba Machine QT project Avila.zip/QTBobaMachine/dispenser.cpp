#include "dispenser.h"
#include "ui_dispenser.h"
#include "bobamachine.h"

void Dispenser::getFlavor(int FlavorRepresentation)
{
   if(FlavorRepresentation==1)
   {
           ui->Flavor->setStyleSheet("QLabel{background-color:purple;}");
   }
   if(FlavorRepresentation==2)
   {

       ui->Flavor->setStyleSheet("QLabel{background-color:yellow;}");
   }
   if(FlavorRepresentation==3)
   {

       ui->Flavor->setStyleSheet("QLabel{background-color:red;}");
   }
   if(FlavorRepresentation==4)
   {

       ui->Flavor->setStyleSheet("QLabel{background-color:brown;}");
   }
animate_background();
}

Dispenser::~Dispenser()
{
    delete ui;
}

void Dispenser::on_pushButton_clicked()
{
BobaMachine* boba = new BobaMachine(this);
boba->show();
this->hide();
}

void Dispenser::animate_background()
{
    Dispensing = new QPropertyAnimation(ui->Flavor,"geometry");
      connect(Dispensing, SIGNAL(finished()), this,SLOT(finished_state()));
   Dispensing->setDuration(10000);
  Dispensing->setStartValue(QRect(2,-1,801,581));
 Dispensing->setEndValue(QRect(2,579,801,581));
 Dispensing->start();


}

Dispenser::Dispenser(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Dispenser)
{
    ui->setupUi(this);
    BobaMachine Boba;
    ui->pushButton->hide();


}

void Dispenser::finished_state()
{
    ui->label->setText("Finished");
    ui->pushButton->show();

}
