#ifndef BOBAMACHINE_H
#define BOBAMACHINE_H

#include <QMainWindow>
#include <QPropertyAnimation>
#include <QPixmap>
#include <QTimer>
#include<QPropertyAnimation>
#include <QString>
#include<QProcess>
#include "dispenser.h"
#include<QScreen>




QT_BEGIN_NAMESPACE
namespace Ui { class BobaMachine; }
QT_END_NAMESPACE

class BobaMachine : public QMainWindow
{
    Q_OBJECT

public:
    BobaMachine(QWidget *parent = nullptr);


    bool WatermelonButtonClicked = false;
bool MangoButtonClicked = false;
bool TaroButtonClicked = false;
bool Milk_TeaButtonClicked = false;


    ~BobaMachine();

private slots:

    void on_MangoButton_clicked();

    void on_WatermelonButton_clicked();

    void on_horizontalSlider_valueChanged(int value);

    void Taro_Button_clicked();

    void on_Milk_Tea_Button_clicked();
    void animateBoba(QString source);
    void FlavorSelection_accepted();
    void CheckButtons();

    void on_FlavorSelection_rejected();

    void on_TapiocaSelection_accepted();

    void on_TapiocaSelection_rejected();

    void on_Go_Back_Button_clicked();

    void on_Make_clicked();

private:


    QPropertyAnimation *Flavoranimation;
    QPropertyAnimation *Tapiocaanimation;



Dispenser* Dispense;


    Ui::BobaMachine *ui;

};
#endif // BOBAMACHINE_H
