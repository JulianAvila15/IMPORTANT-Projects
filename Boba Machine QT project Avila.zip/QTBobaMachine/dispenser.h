#ifndef DISPENSER_H
#define DISPENSER_H

#include <QMainWindow>
#include<QPropertyAnimation>
#include<QObject>

namespace Ui {
class Dispenser;
}

class Dispenser : public QMainWindow
{
    Q_OBJECT

public:
      void getFlavor(int FlavorRepresentation);
    explicit Dispenser(QWidget *parent = nullptr);
    ~Dispenser();

private slots:
      void on_pushButton_clicked();
      void animate_background();
      void finished_state();




private:
    Ui::Dispenser *ui;
    QPropertyAnimation* Dispensing;

};

#endif // DISPENSER_H
