#ifndef FINISHEDBOBA_H
#define FINISHEDBOBA_H

#include <QMainWindow>

namespace Ui {
class FinishedBoba;
}

class FinishedBoba : public QMainWindow
{
    Q_OBJECT

public:
    explicit FinishedBoba(QWidget *parent = nullptr);
    ~FinishedBoba();

private:
    Ui::FinishedBoba *ui;
};

#endif // FINISHEDBOBA_H
