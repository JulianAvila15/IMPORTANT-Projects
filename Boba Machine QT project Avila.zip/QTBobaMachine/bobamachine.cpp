#include "bobamachine.h"
#include "ui_bobamachine.h"




BobaMachine::~BobaMachine()
{
    delete ui;
}

void BobaMachine::animateBoba(QString source)
{

    QPixmap Flavor_filling(source);
    ui->Filling->setVisible(true);
     ui->Filling->setPixmap(Flavor_filling.scaled(150,150,Qt::KeepAspectRatio));
    Flavoranimation = new QPropertyAnimation(ui->Filling,"geometry");
    Flavoranimation->setDuration(1000);
    Flavoranimation->setStartValue(QRect(200,190,0,0));
    Flavoranimation->setEndValue(QRect(200,58,1000,125));
    Flavoranimation->start();
}

void BobaMachine::on_WatermelonButton_clicked()
{

  MangoButtonClicked = false;
  TaroButtonClicked = false;
  Milk_TeaButtonClicked = false;
  WatermelonButtonClicked = true;
  animateBoba("C:/Users/jayli/Documents/QTBobaMachine/images/watermelon_filled.png");

   ui->SpeechBubble_text->setText("Watermelon!");

   CheckButtons();


}


void BobaMachine::on_MangoButton_clicked()
{

    MangoButtonClicked = true;
    TaroButtonClicked = false;
    Milk_TeaButtonClicked = false;
    WatermelonButtonClicked = false;

    animateBoba("C:/Users/jayli/Documents/QTBobaMachine/images/mango_filled.png");

    ui->SpeechBubble_text->setText("Mango!");

   CheckButtons();





}


void BobaMachine::on_horizontalSlider_valueChanged(int value)
{

    if(value<100)
     {
    Tapiocaanimation = new QPropertyAnimation(ui->Tapioca,"size");
     ui->Tapioca->setVisible(true);
     Tapiocaanimation->setDuration(3000);
     Tapiocaanimation->setStartValue(QSize(100,0));

    value+=2;
     ui->Tapioca->setGeometry(200, 190-value, 100, 0+value);

     Tapiocaanimation->setEndValue(QSize(100,0+value));
     Tapiocaanimation->start();
}
    ui->SpeechBubble_text->setText("Ready or you\n can restart?");
    ui->Make->show();

}


void BobaMachine::Taro_Button_clicked()
{
    MangoButtonClicked = false;
    TaroButtonClicked = true;
    Milk_TeaButtonClicked = false;
    WatermelonButtonClicked = false;

    animateBoba("C:/Users/jayli/Documents/QTBobaMachine/images/Taro_filled.png");
    ui->SpeechBubble_text->setText("Taro!,or Ube");


   CheckButtons();

}


void BobaMachine::on_Milk_Tea_Button_clicked()
{
    Milk_TeaButtonClicked = true;
    MangoButtonClicked = false;
    TaroButtonClicked = false;
    WatermelonButtonClicked = false;

    animateBoba("C:/Users/jayli/Documents/QTBobaMachine/images/Milk Tea_filled.png");
     ui->SpeechBubble_text->setText("Milk Tea!");
        CheckButtons();


}

void BobaMachine::CheckButtons()//enables actions if one of the buttons is at least selected
{

    if(TaroButtonClicked||WatermelonButtonClicked||Milk_TeaButtonClicked||MangoButtonClicked)
    {
        ui->FlavorSelection->setVisible(true);
        ui->MangoButton->setVisible(false);
         ui->Taro_Button->setVisible(false);
          ui->WatermelonButton->setVisible(false);
           ui->Milk_Tea_Button->setVisible(false);
           if(TaroButtonClicked)
           {
               ui->Watermelon_label->setVisible(false);
               ui->Mango_label->setVisible(false);
               ui->Milk_teaLabel->setVisible(false);

           }
           else if(WatermelonButtonClicked)
              {
               ui->Taro_Label->setVisible(false);
               ui->Mango_label->setVisible(false);
               ui->Milk_teaLabel->setVisible(false);
           }
           else if(MangoButtonClicked)
           {
               ui->Taro_Label->setVisible(false);
               ui->Watermelon_label->setVisible(false);
               ui->Milk_teaLabel->setVisible(false);
           }
           else if(Milk_TeaButtonClicked)
           {
               ui->Taro_Label->setVisible(false);
               ui->Watermelon_label->setVisible(false);
               ui->Mango_label->setVisible(false);
           }


    }

}

BobaMachine::BobaMachine(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::BobaMachine)
{
    ui->setupUi(this);


    ui->Watermelon_label->setFixedSize(QSize(130,130));
    ui->Mango_label->setFixedSize(QSize(130,130));
    ui->Taro_Label->setFixedSize(QSize(130,130));
     ui->Milk_teaLabel->setFixedSize(QSize(130,130));
    QPixmap Watermelon("C:/Users/jayli/Documents/QTBobaMachine/images/Watermelon.png");
    ui->Watermelon_label->setPixmap(Watermelon.scaled(ui->Watermelon_label->width(),ui->Watermelon_label->height(),Qt::KeepAspectRatio));
    QPixmap Mango("C:/Users/jayli/Documents/QTBobaMachine/images/Mango.png");
    ui->Mango_label->setPixmap(Mango.scaled(ui->Mango_label->width(),ui->Mango_label->height(),Qt::KeepAspectRatio));
    QPixmap Taro("C:/Users/jayli/Documents/QTBobaMachine/images/Taro.png");
    ui->Taro_Label->setPixmap(Taro.scaled(ui->Taro_Label->width(),ui->Taro_Label->height(),Qt::KeepAspectRatio));
    QPixmap Milk_Tea("C:/Users/jayli/Documents/QTBobaMachine/images/Milk Tea.png");
    ui->Milk_teaLabel->setPixmap(Milk_Tea.scaled(ui->Milk_teaLabel->width(),ui->Milk_teaLabel->height(),Qt::KeepAspectRatio));
    QPixmap Background("C:/Users/jayli/Documents/QTBobaMachine/images/Boba_Shop2.jpg");
    ui->Background->setPixmap(Background.scaled(900,900,Qt::KeepAspectRatio));
    QPixmap Menu_background("C:/Users/jayli/Documents/QTBobaMachine/images/menu.jpg");
    ui->Menu->setPixmap(Menu_background.scaled(300,150,Qt::KeepAspectRatio));

    QPixmap empty_cup("C:/Users/jayli/Documents/QTBobaMachine/images/empty cup.png");
    ui->Cup->setPixmap(empty_cup.scaled(150,150,Qt::KeepAspectRatio));
    QPixmap speech_bubble("C:/Users/jayli/Documents/QTBobaMachine/images/speech-bubble-png.png");
    ui->Speech_Bubble->setPixmap(speech_bubble.scaled(180,180,Qt::KeepAspectRatio));
    QPixmap Tapioca_Pix("C:/Users/jayli/Documents/QTBobaMachine/images/Tapioca.png");
    ui->Tapioca->setPixmap(Tapioca_Pix.scaled(ui->Filling->width(),ui->Filling->height(),Qt::KeepAspectRatio));


    connect(ui->FlavorSelection, SIGNAL(accepted()), this, SLOT(FlavorSelection_accepted()));
      connect(ui->Taro_Button, SIGNAL(clicked()), this, SLOT(Taro_Button_clicked()));


    ui->SpeechBubble_text->setText("I am Captain Ginyu,\nWhat will you like today?");
    ui->Filling->setVisible(false);

    ui->horizontalSlider->setVisible(false);
    ui->Make->setVisible(false);
    ui->TapiocaSelection->setVisible(false);
    ui->FlavorSelection->setVisible(false);
        ui->Tapioca->setVisible(false);
        ui->Go_Back_Button->setVisible(false);





}




void BobaMachine::FlavorSelection_accepted()
{

      ui->FlavorSelection->setVisible(false);
      ui->SpeechBubble_text->setText("Do you\nwant Tapioca?");
      ui->TapiocaSelection->setVisible(true);
      ui->Go_Back_Button->setVisible(true);


}


void BobaMachine::on_FlavorSelection_rejected()
{
    static int counter = 0;

      ui->SpeechBubble_text->setText("What will it be?");
      ui->Filling->setVisible(false);
      ui->FlavorSelection->setVisible(false);
      ui->TapiocaSelection->setVisible(false);
      ui->Tapioca->setVisible(false);
      ui->horizontalSlider->setVisible(false);
      ui->Go_Back_Button->setVisible(false);
      ui->Make->hide();

      ui->MangoButton->setVisible(true);
       ui->Taro_Button->setVisible(true);
        ui->WatermelonButton->setVisible(true);
         ui->Milk_Tea_Button->setVisible(true);

         ui->Taro_Label->setVisible(true);
         ui->Milk_teaLabel->setVisible(true);
         ui->Mango_label->setVisible(true);
         ui->Watermelon_label->setVisible(true);


     if(counter>=7)
      {
             ui->SpeechBubble_text->setText("OH MY GOD\nMOVE WITH HASTE!!");
      }
      else if(counter>=5)
      {
                 ui->SpeechBubble_text->setText("HURRY IT \nUP DAMN IT!!");

      }
      else if(counter<5&&counter>3)
      {
            ui->SpeechBubble_text->setText("I don't \nhave all day...");
      }
      else if(counter>=2)
      {
            ui->SpeechBubble_text->setText("Being indecisive\n are we?");
      }

    counter++;
}


void BobaMachine::on_TapiocaSelection_accepted()
{
    ui->horizontalSlider->setVisible(true);
    ui->TapiocaSelection->setVisible(false);
    ui->SpeechBubble_text->setText("How much\ndo you want?");
}


void BobaMachine::on_TapiocaSelection_rejected()
{

    ui->Make->show();
    ui->SpeechBubble_text->setText("Ready? or you\ncan restart?");
    ui->TapiocaSelection->hide();
}


void BobaMachine::on_Go_Back_Button_clicked()
{
      ui->horizontalSlider->setValue(0);
    on_FlavorSelection_rejected();
}


void BobaMachine::on_Make_clicked()
{
//taro mango watermelon milk tea
Dispenser* dlg = new Dispenser(this);
if(TaroButtonClicked)
dlg->getFlavor(1);
else if(MangoButtonClicked)
dlg->getFlavor(2);
else if(WatermelonButtonClicked)
dlg->getFlavor(3);
else if(Milk_TeaButtonClicked)
dlg->getFlavor(4);

 this->close();
dlg->show();


}



