#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc,char** argv){
if(argc!=2)
{
        printf("Error:Not enough or too many arguments\n");
        return 0;
}
if (unlink(argv[1]) == 0||rmdir(argv[1])==0) {
printf("The file is deleted successfully.\n");
} else {
printf("Error: The file is not deleted.\n");
}
return 0;
}
