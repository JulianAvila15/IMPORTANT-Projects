#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char** argv)
{
if(argc<3)
{
puts("Not enough arguments");
return 0;
}
int status = rename(argv[1],argv[2]);
if(status<0)
{
puts("Unsuccessful move");
        return 0;
}
else
{
 puts("Successfully moved");
}
}
