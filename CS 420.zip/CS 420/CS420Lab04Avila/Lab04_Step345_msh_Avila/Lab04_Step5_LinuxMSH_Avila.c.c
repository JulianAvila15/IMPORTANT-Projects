#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>

int main(int argc, char** argv)
{
int pid = fork();

if(strcmp( argv[1],"mycopy")==0)
{
if(pid!=0)
wait(NULL);

else
{
if(argc!=4)
{
puts("Too many or too little  arguments for mycopy command");
return 0;
}
execl(argv[1],argv[1],argv[2],argv[3],0);
}
}

else if(strcmp(argv[1],"myremove")==0)
{
if(pid!=0)
wait(NULL);

else
{
  if(argc!=3)
{
puts("Too many or too little  arguments for myremove command");
return 0;
}
execl(argv[1],argv[1],argv[2],0);
}
}
else if(strcmp(argv[1],"mymove")==0)
{

if(pid!=0)
{
wait(NULL);
}
else{
if(argc!=4)
{
puts("Too many or too little  arguments for mymove command");
return 0;
}
execl(argv[1],argv[1],argv[2],argv[3],0);
}
}
else
{
        if(pid!=0)
        wait(NULL);
        else
        puts("Command not recognized");
}
return 0;
}
