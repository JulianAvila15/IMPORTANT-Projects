#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#define BUFF_SIZE  1024000

int main(int argc,char** argv)
{
if(argc!=2){
printf("error");
return 0;
}
FILE *fp;
fp = fopen(argv[1],"w");

for(size_t i=0; i<BUFF_SIZE;i++){
        fputc('A',fp);
}
fclose(fp);
return 0;
}
