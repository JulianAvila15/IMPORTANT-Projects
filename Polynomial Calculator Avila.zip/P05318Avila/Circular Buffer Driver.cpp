// main.cpp

/*  REQUIREMENTS NOTES:

    Fill in the remainder of this driver program.
    Replicate exactly the sample run provided with project's specs.
    Use a capacity of 5

*/
#include <iostream>
#include <algorithm>
#include <iterator>
#include <vector>
#include "circular_buffer.h"
#include "dog.h"

using namespace std;

int main() {
    cout << "\n*************** <int> Circular Buffer Demo ******************\n";
    //  FINISH THIS SECTION

    CircularBuffer<int, 5> buffer;

    cout << "\nInitial state" << endl;
    cout << buffer;

    for (int i = 0; i < 80; i += 10)
    {

        buffer.push_back(i);
        cout << "Pushing " << i << endl;
        cout << buffer << endl;

    }
    for (int i = 0; i < 5; i++)
    {
        cout << "Popping " << buffer.head() << endl;
        buffer.pop();
        cout << buffer << endl;
    }

    cout << "\n*************** <string> Circular Buffer Demo ******************\n";

    //  FINISH THIS SECTION --
    // create a vector of words
    // use back_insert_iterator to fill the buffer

    vector<string> vect;
    string test = "Hello there The wonderful world of oz ";
    string temp;
    CircularBuffer <string, 5> Buffs;

    cout << "\nInitial state" << endl;
    cout << Buffs;

    cout << "After using back_insert_iterator" << endl;

    for (auto i = test.begin(); i != test.end(); i++)
    {
        if (!isspace(*i))
            temp += *i;
        else
        {
            vect.push_back(temp);
            temp.clear();
        }
    }

    std::back_insert_iterator<CircularBuffer<string, 5>>back_it(Buffs);

    std::copy(vect.begin(), vect.end(), back_it);

    cout << Buffs;

    for (int i = 0; i < Buffs.capacity(); i++)
    {
        cout << "Popping: " << Buffs.head() << endl;
        Buffs.pop();
        cout << Buffs;
    }





    cout << "\n*************** <Dog> Circular Buffer Demo ******************\n";

    //  FINISH THIS SECTION

    CircularBuffer<dog, 5> bufferd;
    bufferd.push_back(dog("Guinness", "Wheaten", 9));
    bufferd.push_back(dog("Grimlock", "Lab", 2));
    bufferd.push_back(dog("Optimus", "Bulldog", 5));
    bufferd.push_back(dog("Murphy", "Lab", 14));
    bufferd.push_back(dog("Floyd", "Beagle", 12));
    cout << bufferd;

    cout << "\ndogs Full?: ";

    if (bufferd.full())
        cout << "true" << endl << endl;
    else
        cout << "false";


    bufferd.push_back(dog("Snoopy", "Beagle", 100));
    cout << bufferd << endl;
    bufferd.push_back(dog("Archie", "Brittany", 1));
    cout << bufferd << endl;
    bufferd.push_back(dog("Penny", "Beagle", 2));
    cout << bufferd << endl;

    for (int i = 0; i < 5; i++)
    {
        cout << "Popping: " << bufferd.head() << endl << endl;
        bufferd.pop();
        cout << bufferd << endl;
    }
}
